<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Users;
use App\Http\Controllers\Auth;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\UsersRequest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Http\FormRequest;

class UsersController extends ApiController {

    /**
     * Show a list of users
     * @return \Illuminate\View\View
     */
    public function index(Request $request) {
        $request = $request->all();
        $page = $request['page'];
        $offset = $request['offset'];
        $search = $request['search'];
        $users = Users::skip($page)->take($offset)->where('name', 'like', "$search%")->get();
        $status = '';
        $message = '';
        if (count($users) > 0) {
            $status = true;
            $message = 'Get User list';
        } else {
            $status = false;
            $message = 'Record not found';
        }
        return $this->respond([
                    'status' => $status,
                    'status_code' => $this->getStatusCode(),
                    'message' => $message,
                    'user' => $users,
                    'count' => $this->getTotalUsers($search),
        ]);
    }

    /**
     * Insert new user into the system
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storedata(Request $request) {
        $input = $request->all();

        $rules = array(
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'mobile' => 'required|numeric',
        );
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
        } else {
            $createUser = Users::create($input);
            return $this->respond([
                        'status' => true,
                        'status_code' => $this->getStatusCode(),
                        'message' => 'User added successfully',
            ]);
        }
    }

    /**
     * get total number of records of users
     */
    public function getTotalUsers($search) {
        return Users::where('name', 'like', "$search%")->count();
    }

}
