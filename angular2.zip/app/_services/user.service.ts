﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { config } from '../config/config';
import 'rxjs/add/operator/map'

@Injectable()
export class UserService {
      public headers:any;
      public options:any;

      constructor(private http: Http){
      var headerData = this.getHeaders();
      this.headers = new Headers(headerData);
      this.options = new RequestOptions({ headers: this.headers });
    }


     public getHeaders(){

        let headerData = {
          "Content-Type": "application/json"
         }
         return headerData;
    }
    /**
     * @Method: getAll(parma1, param2)
     * @Param: Pages, search
     **/
    getAll(pages:any = '', search:any = '') {
        return this.http.get(config.GET_ALL_USER_API_URL+'?page='+pages+'&offset='+config.RECORD_PER_PAGE+'&search='+search).map((response: Response) => response.json());
    }
     /**
      * @Method: create(param)
      * @Param: userData, userData has the user details json object
      **/
    create(userData:any) {
        return this.http.post(config.SAVE_USER_API_URL, userData, this.options).map((response: Response) => response.json());
    }
}