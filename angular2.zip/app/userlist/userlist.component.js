"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var index_1 = require("../_services/index");
var config_1 = require("../config/config");
var UserListComponent = /** @class */ (function () {
    function UserListComponent(router, userService) {
        this.router = router;
        this.userService = userService;
        /** Declaration of variables **/
        this.pages = 0;
        this.searchValue = '';
        this.loading = false;
        this.getUserList = [];
        this.recordPerPage = config_1.config.RECORD_PER_PAGE; // Number of records per page
        this.totalRecords = 0; // Set total records zero as default
        this.noRecordFount = false;
        /** Call getAllUsers() to load user list **/
        this.getAllUsers();
    }
    /**
     * @Method: getAllUsers(),
     * @Desc: Function to get all users
     * @ReturnType: JSON response
     **/
    UserListComponent.prototype.getAllUsers = function () {
        this.getUserListData();
    };
    /**
     * @Method:  pageChanged(param),
     * @Desc: Get users list by pagination
     * @Param: event, page number
     * @ReturnType: JSON response
     **/
    UserListComponent.prototype.pageChanged = function (event) {
        console.log(event);
        this.pages = event;
        this.loading = true;
        this.getUserListData();
    };
    /**
     * @Method:  searchUser(param),
     * @Desc: Get users list by pagination
     * @Param: value, search value
     **/
    UserListComponent.prototype.searchUser = function (value) {
        this.pages = 0;
        this.searchValue = value;
        this.getUserListData();
    };
    /**
     * @Method:  getUserListData(),
     * @Desc: Get users list
     * @ReturnType: JSON response
     **/
    UserListComponent.prototype.getUserListData = function () {
        var _this = this;
        this.loading = true;
        this.userService.getAll(this.pages, this.searchValue)
            .subscribe(function (response) {
            if (response.status) {
                _this.getUserList = response.user;
                _this.totalRecords = response.count;
                console.log(response);
            }
            else {
                _this.noRecordFount = true;
            }
            _this.loading = false;
        }, function (error) {
            _this.loading = false;
        });
    };
    UserListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            templateUrl: 'userlist.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router, index_1.UserService])
    ], UserListComponent);
    return UserListComponent;
}());
exports.UserListComponent = UserListComponent;
