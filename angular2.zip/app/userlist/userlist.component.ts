﻿import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {  UserService  } from '../_services/index';
import { config } from '../config/config';

@Component({
    moduleId: module.id,
    templateUrl: 'userlist.component.html'
})

export class UserListComponent {
    /** Declaration of variables **/
    public pages: number = 0;    
    public searchValue:string = '';
    public loading:boolean = false;
    public getUserList:any = [];
    public recordPerPage:number = config.RECORD_PER_PAGE; // Number of records per page
    public totalRecords:number = 0; // Set total records zero as default
    public noRecordFount:boolean = false;
    constructor(private router: Router,private userService: UserService) {
        /** Call getAllUsers() to load user list **/
        this.getAllUsers();
    }

    /**
     * @Method: getAllUsers(),
     * @Desc: Function to get all users
     * @ReturnType: JSON response
     **/    
    getAllUsers() {
        this.getUserListData();
    }

    /**
     * @Method:  pageChanged(param),
     * @Desc: Get users list by pagination
     * @Param: event, page number
     * @ReturnType: JSON response  
     **/
    pageChanged(event:any) {
      console.log(event);
      this.pages = event;
      this.loading = true;
      this.getUserListData();
    }

    /**
     * @Method:  searchUser(param),
     * @Desc: Get users list by pagination
     * @Param: value, search value 
     **/
    searchUser(value:any){
       this.pages = 0; 
       this.searchValue = value;
       this.getUserListData();
    }

    /**
     * @Method:  getUserListData(),
     * @Desc: Get users list
     * @ReturnType: JSON response  
     **/
    getUserListData() {
        this.loading = true;
        this.userService.getAll(this.pages, this.searchValue)
            .subscribe(
              response => {
                if(response.status) {
                      this.getUserList = response.user;
                      this.totalRecords = response.count;
                      console.log(response)
                    } else {
                      this.noRecordFount = true;
                    }
                    this.loading = false;
                },
                error => {
                    this.loading = false;
                });
    }
    
}
