﻿import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './register/index';
import { UserListComponent } from './userlist/index';


const appRoutes: Routes = [
{ path: 'user-list', component: UserListComponent },
{ path: '', component: RegisterComponent },
];

export const routing = RouterModule.forRoot(appRoutes);