"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var index_1 = require("./register/index");
var index_2 = require("./userlist/index");
var appRoutes = [
    { path: 'user-list', component: index_2.UserListComponent },
    { path: '', component: index_1.RegisterComponent },
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
