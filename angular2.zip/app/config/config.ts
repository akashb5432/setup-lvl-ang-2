/**
 * @Description: Config file used to declare the globale
 * variables that will be used throughout the project
 * in components or in the services
 **/
export var API_URL = 'http://localhost/api/v1/';
export var config = {
    RECORD_PER_PAGE: 2,
    SAVE_USER_API_URL: API_URL + "save",
	GET_ALL_USER_API_URL: API_URL + "users"
}