"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ValidationService = /** @class */ (function () {
    function ValidationService() {
    }
    ValidationService.getValidatorErrorMessage = function (validatorName, validatorValue) {
        var config = {
            'required': 'This field is required',
            'invalidEmailAddress': 'Invalid email address',
            'invalidMobile': 'Please enter 10 digit valid mobile number',
        };
        return config[validatorName];
    };
    /**
     * @Method: emailValidator(param),
     * @Desc: Validate email address
     * @ReturnType: ture/false
     **/
    ValidationService.emailValidator = function (control) {
        var EMAIL_REGEXP = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (EMAIL_REGEXP.test(control.value)) {
            return null;
        }
        else {
            return { 'invalidEmailAddress': true };
        }
    };
    /**
     * @Method: mobileValidate(param),
     * @Desc: Validate email address
     * @ReturnType: ture/false
     **/
    ValidationService.mobileValidate = function (control) {
        var EMAIL_REGEXP = /^\d{10}$/;
        if (EMAIL_REGEXP.test(control.value)) {
            return null;
        }
        else {
            return { 'invalidMobile': true };
        }
    };
    return ValidationService;
}());
exports.ValidationService = ValidationService;
