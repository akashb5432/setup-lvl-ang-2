"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @Description: Config file used to declare the globale
 * variables that will be used throughout the project
 * in components or in the services
 **/
exports.API_URL = 'http://localhost/api/v1/';
exports.config = {
    RECORD_PER_PAGE: 2,
    SAVE_USER_API_URL: exports.API_URL + "save",
    GET_ALL_USER_API_URL: exports.API_URL + "users"
};
