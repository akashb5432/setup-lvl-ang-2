﻿import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {IMyDpOptions} from 'mydatepicker';

import { UserService } from '../_services/index';
import { ValidationService } from '../config/validation.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    moduleId: module.id,
    templateUrl: 'register.component.html'
})

export class RegisterComponent {
    /** Declaration of variables **/
    public model: any = {};
    public loading = false;
    public errorMessage:any = '';
    public successMessage:any = '';
    public alertBox:boolean = false;
    public successBox:boolean = false;
    public formData:any = {};
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'yyyy-mm-dd',
        editableDateField: false
    };
    public userForm: any;
    constructor(
        private router: Router,
        private userService: UserService,
        private formBuilder: FormBuilder) { 
            /** Declare formData json**/
            this.formData = {
                name: '',
                email: '',
                mobile: '',
                dob: ''
            }
            /**Adding validation on form using validators**/
            this.userForm = this.formBuilder.group({
              'name': ['', Validators.required],
              'email': ['', [Validators.required, ValidationService.emailValidator]],
              'mobile': ['', [Validators.required,ValidationService.mobileValidate, Validators.minLength(10), Validators.maxLength(10)]],
              'dob': ['', [Validators.required]],
            });
        }
        
    /**
     * @Method: saveUser(),
     * @Desc: Save user details,
     * @ReturType: JSON response,
     **/    
    saveUser() {
        this.loading = true;
        this.formData.name = this.model.name;
        this.formData.email = this.model.email;
        this.formData.mobile = this.model.mobile;
        this.formData.dob = this.model.dob.formatted;
        this.userService.create(this.formData)
            .subscribe(
                response => {
                    this.loading = false;
                    if(response.status){
                      this.alertBox = false;
                      this.successBox = true;
                      this.successMessage = response.message;
                    } else {
                      this.successBox = false;
                      this.alertBox = true;
                      this.errorMessage = response.data;
                    }
                },
                error => {
                    this.loading = false;
                });
    }
}
